"""External integration adapters for Threshold."""
