"""Application services that coordinate durable delivery and recovery."""
